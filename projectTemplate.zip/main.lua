local test = require "plugin.test"

display.newText(test.firstFunction(), display.contentCenterX, display.contentCenterY, nil, 32)