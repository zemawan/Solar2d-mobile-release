package plugin.test;

import com.naef.jnlua.JavaFunction;
import com.naef.jnlua.LuaState;
import com.naef.jnlua.NamedJavaFunction;

@SuppressWarnings({"WeakerAccess", "unused"})
public class LuaLoader implements JavaFunction {
	@Override
	public int invoke(LuaState luaState) {
		luaState.register(luaState.toString(1), new NamedJavaFunction[]{new FirstFunction()});
		return 1;
	}
}