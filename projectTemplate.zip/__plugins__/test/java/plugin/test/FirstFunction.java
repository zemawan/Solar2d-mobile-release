package plugin.test;

import com.naef.jnlua.LuaState;

public class FirstFunction implements com.naef.jnlua.NamedJavaFunction {
    @Override
    public String getName() {
        return "firstFunction";
    }

    @Override
    public int invoke(final LuaState luaState) {
        luaState.pushString("Hello world!");
        return 1;
    }
}